package com.nhnacademy.familycertification.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HouseholdMovementAddressUpdateDTO {

    private Long householdSerialNumber;
    private String houseMovementAddress;
}
