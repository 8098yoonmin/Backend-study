package com.nhnacademy.board.repository;

public interface RepositoryBase {
}
