import org.apache.commons.cli.*;

import java.io.IOException;

public class Argument {
    public static void main(String[] args) {
        Options options = MakeOption.getOption();

        CommandLineParser parser = new DefaultParser();
        boolean verbose = false;
        boolean redirect = false;
        boolean file = false;
        String url = "";
        String method = "GET";
        String header = "";
        String body = "";
        String filePath = "";

        try {
            CommandLine cmd = parser.parse(options, args);

            if (cmd.hasOption("h")) {
                HelpFormatter helpFormatter = new HelpFormatter();
                helpFormatter.printHelp("scurl [options] url", options);
            } else {
                if (cmd.hasOption("v")) {
                    verbose = true;
                }
                if (cmd.hasOption("H")) {
                    header = cmd.getOptionValue("H");
                }
                if (cmd.hasOption("d")) {
                    body = cmd.getOptionValue("d");
                }
                if (cmd.hasOption("X")) {
                    method = cmd.getOptionValue("X");
                }
                if (cmd.hasOption("L")) {
                    redirect = true;
                }
                if (cmd.hasOption("F")) {
                    method = "POST";
                    file = true;
                    filePath = cmd
                            .getOptionProperties("F")
                            .getProperty("upload");
                }
                url = args[args.length - 1];

                Scurl scurl = Scurl.builder(url)
                        .method(method)
                        .header(header)
                        .body(body)
                        .verbose(verbose)
                        .redirect(redirect)
                        .file(file)
                        .filePath(filePath)
                        .build();
                scurl.send();
            }

        } catch (ParseException e) {
            Thread.currentThread().interrupt();
        } catch (IOException e) {
            Thread.currentThread().interrupt();
        }
    }
}
