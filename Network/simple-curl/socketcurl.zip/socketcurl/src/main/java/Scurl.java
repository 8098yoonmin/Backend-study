import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.util.logging.Logger;

public class Scurl {
    private static final String ACCEPT = "Accept";
    private static final String BOUNDARY = "------------------------boundary";
    private static final String CONTENT_DISPOSITION = "Content-Disposition: form-data; name=\"file\"; filename=";
    private static final int REDIRECT_CODE = 300;
    private static final int BAD_REQUEST_CODE = 400;

    private String urlString = "";
    private String method = "";
    private String header = "";
    private String body = "";
    private String filePath = "";
    private boolean verbose;
    private boolean redirect;
    private boolean file;

    private Scurl(final Builder builder) {
        urlString = builder.url;
        method = builder.method;
        header = builder.header;
        body = builder.body;
        verbose = builder.verbose;
        redirect = builder.redirect;
        file = builder.file;
        filePath = builder.filePath;
    }

    public void send() throws IOException {
        File f = null;
        Parsing parsing = new Parsing();

        parsing.setHost(urlString);
        parsing.setPath(urlString);
        InetAddress ip = InetAddress.getByName(new URL(parsing.getHostUrl()).getHost());
        try (Socket socket = new Socket(ip, 80);
             BufferedWriter output = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
             BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {


            parsing.setMethod(method);
            parsing.setRequestHeaderBase();

            if (!header.isBlank()) {
                requestHeader(parsing);
            } else {
                parsing.addRequestHeader(ACCEPT, "*/*");
            }

            if (!file && !body.isBlank()) {
                parsing.addRequestHeader("Content-Type", "application/json");
                parsing.addRequestHeader("Content-Length", String.valueOf(body.length()));
                parsing.setRequestBody(body);
            }

            StringBuilder multipartContentBuilder = new StringBuilder();
            if (file) {
                StringBuilder fileContent = new StringBuilder();
                BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(filePath)));
                String line;
                while ((line = reader.readLine()) != null) {
                    fileContent.append(line);
                }


                parsing.addRequestHeader("Content-Type", "multipart/form-data;charset=urf-8;boundary=" + BOUNDARY);
                multipartContentBuilder
                        .append("--").append(BOUNDARY).append("\r\n")
                        .append(CONTENT_DISPOSITION).append("\"").append(filePath).append("\"").append("\r\n\r\n")
                        .append(fileContent).append("\r\n")
                        .append("--").append(BOUNDARY).append("--").append("\r\n");

                parsing.addRequestHeader("Content-Length", String.valueOf(multipartContentBuilder.length()));
            }

            if (verbose) {
                System.out.println(parsing.getRequestHeader());
            }

            output.write(parsing.getRequestHeader());
            output.write("Connection: close\r\n\r\n");

            if (!body.isBlank()) {
                output.write(parsing.getRequestBody());
                output.newLine();
            }

            if (file) {
                output.write(multipartContentBuilder.toString());
            }

            output.flush();

            String line;
            String location = "";
            int i = 0;
            int statusCode = 0;
            boolean flag = verbose;
            StringBuilder response = new StringBuilder();
            while ((line = input.readLine()) != null) {
                if (flag) {
                    response.append(line).append("\n");
                }
                if (line.isEmpty()) {
                    flag = true;
                }
                if (i == 0) {
                    statusCode = Integer.valueOf(line.split(" ")[1]);
                    i++;
                }
                if (line.contains("location") || line.contains("Location")) {
                    location = line.split(":")[1];
                    location = location.trim();
                }
            }
            System.out.println(response.toString());

            if (redirect && statusCode >= REDIRECT_CODE && statusCode < BAD_REQUEST_CODE) {
                urlString = parsing.getHostUrl() + location;
                method = "GET";
                send();
            } else if (redirect) {
                redirect = false;
            }
        } catch (Exception e) {
            Thread.currentThread().interrupt();
        }
    }

    public void requestHeader(final Parsing parsing) {
        if (header.startsWith(ACCEPT)) {
            parsing.addRequestHeader(
                    header.split(":")[0],
                    header.split(":")[1]
            );
        } else {
            parsing.addRequestHeader(ACCEPT, "*/*");
            parsing.addRequestHeader(
                    header.split(":")[0],
                    header.split(":")[1]
            );
        }
    }


    public static class Builder {
        private boolean verbose = false;
        private boolean redirect = false;
        private boolean file = false;
        private String filePath = "";
        private String url = "";
        private String method = "GET";
        private String header = "";
        private String body = "";

        public Builder(final String url) {
            this.url = url;
        }

        public Builder method(final String method) {
            this.method = method;
            return this;
        }

        public Builder header(final String header) {
            this.header = header;
            return this;
        }

        public Builder body(final String body) {
            this.body = body;
            return this;
        }

        public Builder verbose(final boolean verbose) {
            this.verbose = verbose;
            return this;
        }

        public Builder redirect(final boolean redirect) {
            this.redirect = redirect;
            return this;
        }

        public Builder file(final boolean file) {
            this.file = file;
            return this;
        }

        public Builder filePath(final String filePath) {
            this.filePath = filePath;
            return this;
        }

        public Scurl build() {
            return new Scurl(this);
        }
    }

    public static Builder builder(final String url) {
        return new Builder(url);
    }
}
