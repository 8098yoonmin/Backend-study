public class Parsing {

    private StringBuilder requestHeader;
    private StringBuilder requestBody;
    private String host;
    private String path;
    private String method;

    private int semiColonIndex;
    private int slashIndex;

    public Parsing() {
        requestHeader = new StringBuilder();
        requestBody = new StringBuilder();
    }

    public void setHost(String url) {
        setUrlDistinctIndex(url);
        host = url.substring(semiColonIndex + 3, slashIndex);
    }

    public void setPath(String url) {
        setUrlDistinctIndex(url);
        path = url.substring(slashIndex, url.length());
    }

    public String getHostUrl() {
        return "http://" + host;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public void setRequestHeaderBase() {
        requestHeader.append(method.toUpperCase()).append(" ").append(path).append(" HTTP/1.1\r\n");
        requestHeader.append("Host: ").append(host).append("\r\n");
        requestHeader.append("User-Agent: ").append("scurl/1.0").append("\r\n");
    }

    private void setUrlDistinctIndex(String url) {
        int slashCount = 0;
        semiColonIndex = 0;
        slashIndex = 0;

        for (int i = 0; i < url.length(); i++) {
            if (url.charAt(i) == '/') {
                slashCount++;
            } else if (url.charAt(i) == ':') {
                semiColonIndex = i;
            }
            if (slashCount == 3) {
                slashIndex = i;
                break;
            }
        }
    }

    public void addRequestHeader(String key, String value) {
        requestHeader.append(key).append(": ").append(value).append("\r\n");
    }

    public String getRequestHeader() {
        return requestHeader.toString();
    }

    public void setRequestBody(String body) {
        requestBody.append(body);
    }

    public String getRequestBody() {
        return requestBody.toString();
    }
}
