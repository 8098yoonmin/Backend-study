package com.nhnacademy.springbootstudent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
