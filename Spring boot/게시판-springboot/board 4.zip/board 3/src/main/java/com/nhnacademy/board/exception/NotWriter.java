package com.nhnacademy.board.exception;

public class NotWriter extends RuntimeException{

}
