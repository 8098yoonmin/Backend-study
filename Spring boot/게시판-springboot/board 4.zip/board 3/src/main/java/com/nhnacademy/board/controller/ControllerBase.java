package com.nhnacademy.board.controller;

// marker interface
public interface ControllerBase {

}
