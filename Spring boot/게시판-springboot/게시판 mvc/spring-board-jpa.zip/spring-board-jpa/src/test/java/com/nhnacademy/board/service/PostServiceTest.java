package com.nhnacademy.board.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PostServiceTest {

    @Test
    void getId() {
    }

    @Test
    void getPost() {
    }

    @Test
    void delete() {
    }

    @Test
    void getPostList() {
    }

    @Test
    void register() {
    }

    @Test
    void modify() {
    }
}