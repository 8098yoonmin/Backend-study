package com.nhnacademy.board.repository;

// marker interface
public interface RepositoryBase {
}
