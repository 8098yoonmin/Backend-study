package com.nhn.edu.springboot.autoconfig.conditional.conditionaldemo.component;

public class Yes {
}
