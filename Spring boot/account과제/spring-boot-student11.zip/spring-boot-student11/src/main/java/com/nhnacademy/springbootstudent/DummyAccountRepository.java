//package com.nhnacademy.springbootstudent;
//
//import org.springframework.stereotype.Component;
//
//import java.util.List;
//
//@Component
//public class DummyAccountRepository implements AccountRepository {
//    @Override
//    public List<Account> findAll() {
//        return List.of(new Account("112121", 200), new Account("232323", 500));
//    }
//}
