package com.nhnacademy.springmvc.exception;

public class PostNotFoundException extends RuntimeException {
}
