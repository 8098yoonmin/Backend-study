package com.nhnacademy.springmvc.exception;

public class UserAlreadyExistsException extends RuntimeException {
}
