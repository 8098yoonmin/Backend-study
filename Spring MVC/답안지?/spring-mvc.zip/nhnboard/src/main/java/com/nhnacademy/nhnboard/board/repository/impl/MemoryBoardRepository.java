package com.nhnacademy.nhnboard.board.repository.impl;

public class MemoryBoardRepository {
}
