package com.nhnacademy.nhnboard;

public interface Base {
}
