package com.nhnacademy.nhnboard.board.repository;

public interface BoardRepository {
}
