package com.nhnacademy.springmvc.service;

import com.nhnacademy.springmvc.domain.User;
import com.nhnacademy.springmvc.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public void save(User user){
        if(userRepository.existById(user.getUserId())){
            //중복된 아이디 exception
        }
        userRepository.save(user);
    }

    public boolean match(String userId, String userPassword){
        User user = userRepository.getUserById(userId);
        if(Objects.isNull(user)){
            return false;
        }
        return user.getUserPassword().equals(userPassword);
    }

    public User getUser(String userId){
        User user =  userRepository.getUserById(userId);
        if(Objects.isNull(user)){
            //user Not found exception
        }
        return user;
    }
}
