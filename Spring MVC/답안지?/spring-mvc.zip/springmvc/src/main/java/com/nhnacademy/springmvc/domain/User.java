package com.nhnacademy.springmvc.domain;

import java.time.LocalDateTime;

public class User {
    public enum Role {
        ADMIN,USER
    }

    private final String userId;
    private final String userName;
    private final int userAge;
    private final String userPassword;
    private final Role role;
    private final LocalDateTime createdAt;

    public String getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public int getUserAge() {
        return userAge;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public Role getRole() {
        return role;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }


    private User(String userId, String userName, int userAge, String userPassword, Role role) {
        this.userId = userId;
        this.userName = userName;
        this.userAge = userAge;
        this.userPassword = userPassword;
        this.role = role;
        this.createdAt = LocalDateTime.now();
    }

    public static User createAdmin(String userId, String userName, int userAge, String userPassword){
        return new User(userId,userName,userAge,userPassword,Role.ADMIN);
    }

    public static User createUser(String userId, String userName, int userAge, String userPassword){
        return new User(userId,userName,userAge,userPassword,Role.USER);
    }

}
