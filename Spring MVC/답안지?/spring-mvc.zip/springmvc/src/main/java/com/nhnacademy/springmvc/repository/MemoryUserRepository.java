package com.nhnacademy.springmvc.repository;

import com.nhnacademy.springmvc.domain.User;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class MemoryUserRepository implements UserRepository {
    private final ConcurrentMap<String, User>  userMap = new ConcurrentHashMap<>();

    @Override
    public void save(User user) {
        userMap.put(user.getUserId(),user);
    }

    @Override
    public User getUserById(String userId) {
       return userMap.get(userId);
    }

    @Override
    public boolean existById(String userId) {
        return userMap.containsKey(userId);
    }
}
