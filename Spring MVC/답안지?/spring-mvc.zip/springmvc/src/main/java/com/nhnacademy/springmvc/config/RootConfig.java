package com.nhnacademy.springmvc.config;

import com.nhnacademy.springmvc.Base;
import com.nhnacademy.springmvc.domain.User;
import com.nhnacademy.springmvc.repository.MemoryUserRepository;
import com.nhnacademy.springmvc.repository.UserRepository;

import org.apache.commons.math3.random.RandomDataGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;

@Configuration
@ComponentScan(basePackageClasses = {Base.class}, excludeFilters = {@ComponentScan.Filter(Controller.class)})
public class RootConfig {

    @Bean
    public UserRepository memoryUserRepository(){
        MemoryUserRepository memoryUserRepository = new MemoryUserRepository();
        RandomDataGenerator generator = new RandomDataGenerator();
        for(int i=1; i<100; i++){
            User admin = User.createAdmin("admin"+i,"관리자"+i,generator.nextInt(30,100),"1234");
            User user = User.createUser("user"+i,"유저"+i,generator.nextInt(30,100),"1234");
            memoryUserRepository.save(admin);
            memoryUserRepository.save(user);
        }
        return memoryUserRepository;
    }
}
