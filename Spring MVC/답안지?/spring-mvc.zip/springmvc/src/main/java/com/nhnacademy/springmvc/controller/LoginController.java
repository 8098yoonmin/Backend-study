package com.nhnacademy.springmvc.controller;

import com.nhnacademy.springmvc.domain.User;
import com.nhnacademy.springmvc.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
public class LoginController {
    private final UserService userService;

    public LoginController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String login(){
        return "login/loginForm";
    }

    @PostMapping("/login")
    public String doLogin(String userId, String userPassword, HttpServletRequest request){
        if(!userService.match(userId,userPassword)){
            return "redirect:/login";
        }

        User user =  userService.getUser(userId);
        HttpSession session = request.getSession(true);

        session.setAttribute("user",user);
        if(user.getRole().equals(User.Role.USER)){
            return "redirect:/user/";
        }else{
            return "redirect:/admin/";
        }
    }
}
