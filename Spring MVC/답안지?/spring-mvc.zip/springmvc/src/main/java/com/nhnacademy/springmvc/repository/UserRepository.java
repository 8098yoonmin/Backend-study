package com.nhnacademy.springmvc.repository;

import com.nhnacademy.springmvc.domain.User;

import java.util.List;

public interface UserRepository {
    void save(User user);
    User getUserById(String userId);
    boolean existById(String userId);
}

