package com.nhnacademy.board.controller.admin;

public class UserUpdateController {


}
