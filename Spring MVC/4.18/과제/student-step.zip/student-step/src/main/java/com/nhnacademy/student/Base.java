package com.nhnacademy.student;

public interface Base {
}
