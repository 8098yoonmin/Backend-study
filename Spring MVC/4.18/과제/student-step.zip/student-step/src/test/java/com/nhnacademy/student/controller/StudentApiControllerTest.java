package com.nhnacademy.student.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StudentApiControllerTest {

    @Test
    void getStudent() {
    }

    @Test
    void setStudent() {
    }

    @Test
    void updateStudent() {
    }
}