package com.nhnacademy.board.controller.admin;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AdminControllerTest {

    @Test
    void admin() {
    }

    @Test
    void register() {
    }

    @Test
    void addRegister() {
    }

    @Test
    void views() {
    }

    @Test
    void delete() {
    }

    @Test
    void getUpdate() {
    }

    @Test
    void update() {
    }
}