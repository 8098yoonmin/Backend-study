package com.nhnacademy.board.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserServiceTest {

    @Test
    void getUser() {
    }

    @Test
    void delete() {
    }

    @Test
    void getUserList() {
    }

    @Test
    void register() {
    }

    @Test
    void modify() {
    }
}