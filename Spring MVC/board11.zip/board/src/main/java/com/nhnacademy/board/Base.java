package com.nhnacademy.board;

public interface Base {
}
