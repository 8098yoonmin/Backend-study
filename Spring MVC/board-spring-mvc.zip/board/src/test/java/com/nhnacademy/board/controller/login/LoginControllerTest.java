package com.nhnacademy.board.controller.login;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LoginControllerTest {

    @Test
    void getLogin() {
    }

    @Test
    void loginForm() {
    }

    @Test
    void logout() {
    }
}