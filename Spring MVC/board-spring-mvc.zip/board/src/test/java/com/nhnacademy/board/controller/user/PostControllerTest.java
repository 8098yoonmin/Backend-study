package com.nhnacademy.board.controller.user;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PostControllerTest {

    @Test
    void list() {
    }

    @Test
    void addRegister() {
    }

    @Test
    void register() {
    }

    @Test
    void view() {
    }

    @Test
    void testView() {
    }

    @Test
    void getUpdate() {
    }

    @Test
    void update() {
    }
}