package com.nhnacademy.todo.controller;

public interface ControllerBase {
}
