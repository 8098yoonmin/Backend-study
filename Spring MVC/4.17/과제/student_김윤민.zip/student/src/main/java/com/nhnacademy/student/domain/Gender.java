package com.nhnacademy.student.domain;

public enum Gender {
    M,F
}
