package com.nhnacademy.student.exception;

public class PostNotFoundException extends RuntimeException {
}
