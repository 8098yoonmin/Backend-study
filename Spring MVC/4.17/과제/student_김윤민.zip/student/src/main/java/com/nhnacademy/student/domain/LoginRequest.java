package com.nhnacademy.student.domain;

public class LoginRequest {
    private String userId;
    private String userPassword;
    public String getUserId() {
        return userId;
    }
    public String getUserPassword() {
        return userPassword;
    }
}