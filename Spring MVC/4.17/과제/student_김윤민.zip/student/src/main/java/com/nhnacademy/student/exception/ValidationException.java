package com.nhnacademy.student.exception;

public class ValidationException extends RuntimeException{
}
