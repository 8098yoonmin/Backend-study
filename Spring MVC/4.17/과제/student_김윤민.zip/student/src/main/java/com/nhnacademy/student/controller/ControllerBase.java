package com.nhnacademy.student.controller;

public interface ControllerBase {
}