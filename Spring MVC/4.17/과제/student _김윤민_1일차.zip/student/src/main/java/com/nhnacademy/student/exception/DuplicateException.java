package com.nhnacademy.student.exception;

public class DuplicateException extends RuntimeException{
}
