package com.nhnacademy.security;


import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

// TODO #1: 실습
//          `springSecurityFilterChain`라는 이름의 DelegatingFilterProxy filter를 등록해주는
//          Spring Security용 WebApplicationInitializer를 상속받도록 수정해주세요.
public class SecurityInitializer extends AbstractSecurityWebApplicationInitializer {
}
