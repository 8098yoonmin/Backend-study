package com.nhnacademy.security.domain;

import lombok.Data;

@Data
public class MemberId {
    private String id;

}
