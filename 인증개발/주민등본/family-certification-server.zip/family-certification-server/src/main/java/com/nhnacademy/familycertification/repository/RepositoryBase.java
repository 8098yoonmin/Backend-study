package com.nhnacademy.familycertification.repository;

// marker interface
public interface RepositoryBase {
}
