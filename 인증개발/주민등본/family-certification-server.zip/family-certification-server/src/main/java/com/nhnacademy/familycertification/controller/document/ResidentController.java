package com.nhnacademy.familycertification.controller.document;

import com.nhnacademy.familycertification.repository.ResidentRepository;
import com.nhnacademy.familycertification.service.CertificateIssueService;
import com.nhnacademy.familycertification.service.FamilyRelationshipService;
import com.nhnacademy.familycertification.service.HouseholdService;
import com.nhnacademy.familycertification.service.ResidentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;

@RequiredArgsConstructor
@Controller
public class ResidentController {

    private final HouseholdService familyRelationshipService;
    private final CertificateIssueService certificateIssueService;
    private final ResidentService residentService;

}
