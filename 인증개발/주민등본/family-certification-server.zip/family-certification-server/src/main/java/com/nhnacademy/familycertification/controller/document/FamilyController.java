package com.nhnacademy.familycertification.controller.document;


import com.nhnacademy.familycertification.domain.CertificateIssueDTO;
import com.nhnacademy.familycertification.service.CertificateIssueService;
import com.nhnacademy.familycertification.service.FamilyRelationshipService;
import com.nhnacademy.familycertification.service.ResidentService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RequiredArgsConstructor
@Controller
public class FamilyController {

    private final FamilyRelationshipService familyRelationshipService;
    private final CertificateIssueService certificateIssueService;
    private final ResidentService residentService;
    @GetMapping("/index")
    public String index(Model model){
//        CertificateIssueDTO certificateInfo = certificateIssueService.getCertificateInfoByResidentSerialNumber(serialNumber, "가족관계증명서" );
//
//        model.addAttribute("certificateInfo", certificateInfo);
//        model.addAttribute("resident", residentService.findBySerialId(serialNumber));
//        model.addAttribute("familyList", familyRelationshipService.getFamily(serialNumber));
        return "index";
    }
//    @GetMapping("/family/{serialNumber}")
//    public String getFamilyRelationship(@RequestParam(name="id")Long serialNumber,
//                                        Model model) {
//        CertificateIssueDTO certificateInfo = certificateIssueService.getCertificateInfoByResidentSerialNumber(serialNumber, "가족관계증명서" );
//        model.addAttribute("certificateInfo", certificateInfo);
//        model.addAttribute("resident", residentService.findBySerialId(serialNumber));
//        model.addAttribute("familyList", familyRelationshipService.getFamily(serialNumber));
//
//        return "familyRelationship";
//    }

    @GetMapping("/family/4")
    public String getFamilyRelationship(Model model) {
        CertificateIssueDTO certificateInfo = certificateIssueService.getCertificateInfoByResidentSerialNumber((long)4, "가족관계증명서" );
        model.addAttribute("certificateInfo", certificateInfo);
        model.addAttribute("resident", residentService.findBySerialId((long)4));
        model.addAttribute("familyList", familyRelationshipService.getFamily((long)4));

        return "familyRelationship";
    }



}
