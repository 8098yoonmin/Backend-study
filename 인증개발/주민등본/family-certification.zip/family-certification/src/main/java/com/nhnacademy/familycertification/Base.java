package com.nhnacademy.familycertification;

public interface Base {


    
}
