package com.nhnacademy.familycertification.exception;

public class NotFoundResidentException extends RuntimeException{
}