package com.nhnacademy.familycertification.controller;

// marker interface
public interface ControllerBase {
}
