package com.nhnacademy.familycertification.exception;


public class NotExistCertificateException extends RuntimeException{
}