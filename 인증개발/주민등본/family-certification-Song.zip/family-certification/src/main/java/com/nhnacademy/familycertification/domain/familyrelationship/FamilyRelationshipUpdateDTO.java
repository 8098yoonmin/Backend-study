package com.nhnacademy.familycertification.domain.familyrelationship;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class FamilyRelationshipUpdateDTO {
    private String familyRelationshipCode;
}