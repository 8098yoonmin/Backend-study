package com.nhnacademy.familycertification.repository;

import com.nhnacademy.familycertification.entity.CertificateIssue;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CertificateIssueRepository extends JpaRepository<CertificateIssue, Long>,CertificateIssueRepositoryCustom{

    List<CertificateIssue> findByResident_ResidentSerialNumber(Long id);

//    Page<CertificateIssue> getPages(Pageable pageable);

}