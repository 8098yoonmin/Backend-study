package com.nhnacademy.minidooray.hellofront;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloFrontApplicationTests {

	@Test
	void contextLoads() {
	}

}
