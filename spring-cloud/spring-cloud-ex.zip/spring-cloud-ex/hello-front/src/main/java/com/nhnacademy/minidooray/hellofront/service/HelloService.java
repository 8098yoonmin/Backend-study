package com.nhnacademy.minidooray.hellofront.service;

public interface HelloService {
    String callGateway();
}
