package com.nhnacademy.minidooray.hellofront.adaptor;

public interface HelloAdaptor {
    String getApplicationInfo();
}
