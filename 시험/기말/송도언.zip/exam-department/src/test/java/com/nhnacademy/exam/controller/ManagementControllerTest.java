package com.nhnacademy.exam.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
class ManagementControllerTest {

    @Autowired
    MockMvc mockMvc;

    @Test
    @DisplayName("json get")
    void getManagements() throws Exception {
        mockMvc.perform(get("/department-members?departmentIds=L1001")
                        .header("X-USER-ID","nhnacademy")
                        .header("Accept","application/json"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON+";charset=UTF-8"))
                .andExpect(jsonPath("$[0].employee.employeeId",equalTo(20202201)));
    }

    @Test
    @DisplayName("xml get")
    void getManagementsXml() throws Exception {
        mockMvc.perform(get("/department-members?departmentIds=L1001")
                        .header("X-USER-ID","nhnacademy")
                        .header("Accept","application/xml"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_XML+";charset=UTF-8"));
    }

    @Test
    @DisplayName("빈 파라미터")
    void emptyParameter() throws Exception {
        mockMvc.perform(get("/department-members?departmentIds=")
                        .header("X-USER-ID","nhnacademy")
                        .header("Accept","application/json"))
                .andExpect(status().isBadRequest());
    }
    @Test
    @DisplayName("잘못된 파라미터")
    void wrongParameter() throws Exception {
        mockMvc.perform(get("/department-members?departmentIds=1521312")
                        .header("X-USER-ID","nhnacademy")
                        .header("Accept","application/json"))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("잘못된 ID")
    void wrongId() throws Exception {
        mockMvc.perform(get("/department-members?departmentIds=L1001")
                        .header("X-USER-ID","marco")
                        .header("Accept","application/json"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("빈 ID")
    void emptyId() throws Exception {
        mockMvc.perform(get("/department-members?departmentIds=L1001")
                        .header("X-USER-ID","")
                        .header("Accept","application/json"))
                .andExpect(status().isUnauthorized());
    }

}