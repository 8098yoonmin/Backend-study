package com.nhnacademy.exam.repository;

import com.nhnacademy.exam.entity.Department;
import com.nhnacademy.exam.entity.Employee;
import com.nhnacademy.exam.entity.Management;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;


@DataJpaTest
@ActiveProfiles("dev")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class ManagementRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private ManagementRepository managementRepository;
    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    private DepartmentRepository departmentRepository;

    @Test
    void findByDepartment_DepartmentCode() {
        Department actual = new Department("CS121", "적팀");
        entityManager.merge(actual);
        Employee actual2 = new Employee(2211212L,"송도언");
        entityManager.merge(actual2);

        Management management = new Management(new Management.Pk(actual.getDepartmentCode(),
                actual2.getEmployeeId()), actual2,actual);
        entityManager.merge(management);

        List<Management> expect = managementRepository.findByDepartment_DepartmentCode("CS121");
        assertThat(expect.get(0)).isEqualTo(management);

    }
}