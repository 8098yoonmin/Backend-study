package com.nhnacademy.exam.service;

import com.nhnacademy.exam.entity.Department;
import com.nhnacademy.exam.repository.DepartmentRepository;
import com.nhnacademy.exam.request.DepartmentDTO;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;


@SpringBootTest
class DepartmentServiceTest {

    @Autowired
    DepartmentService departmentService;
    @Autowired
    DepartmentRepository departmentRepository;

    @Test
    void getDepartment() {
        Department department = new Department("CS123","우리팀");
        departmentRepository.save(department);

        Optional<Department> actual =departmentRepository.findById("CS123");

        Assertions.assertThat(actual).isPresent();
        Assertions.assertThat(actual.get()).isEqualTo(department);
    }

    @Test
    void createDepartment() {
        DepartmentDTO dto = new DepartmentDTO("CS122","상대팀");
        Department department = new Department(dto.getId(),dto.getName());
        departmentRepository.save(department);

        Optional<Department> actual =departmentRepository.findById("CS122");

        Assertions.assertThat(actual).isPresent();
        Assertions.assertThat(actual.get()).isEqualTo(department);
    }

    @Test
    void updateDepartment() {
        DepartmentDTO dto = new DepartmentDTO();
        dto.setName("상대팀");
        Department department = new Department("CS123","우리팀");
        Department department2 = new Department("CS123","상대팀");
        departmentRepository.save(department);

        departmentService.updateDepartment("CS123",dto);
        Optional<Department> actual =departmentRepository.findById("CS123");

        Assertions.assertThat(actual.get()).isEqualTo(department2);
    }

    @Test
    void deleteDepartment() {
        Department department = new Department("CS121","적팀");
        departmentRepository.save(department);


        Optional<Department> actual =departmentRepository.findById("CS121");
        Assertions.assertThat(actual).isPresent();
        departmentRepository.delete(department);
        Department actual2 =departmentRepository.findById("CS121").orElse(null);
        Assertions.assertThat(actual2).isNull();
    }

    @Test
    void existsDepartment() {
        Department department = new Department("CS125","우리팀");

        departmentRepository.save(department);
        Optional<Department> actual =departmentRepository.findById("CS125");
        Assertions.assertThat(departmentRepository.existsById(actual.get().getDepartmentCode())).isTrue();
    }
}