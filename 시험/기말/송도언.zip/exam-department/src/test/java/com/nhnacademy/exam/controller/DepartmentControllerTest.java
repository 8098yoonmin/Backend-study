package com.nhnacademy.exam.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nhnacademy.exam.request.DepartmentDTO;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class DepartmentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @Order(1)
    void createDepartment() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        DepartmentDTO dto = new DepartmentDTO("CS0002","고객서비스2팀");
        mockMvc.perform(post("/departments")
                        .content(objectMapper.writeValueAsString(dto))
                        .header("X-USER-ID","nhnacademy")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE+";charset=UTF-8"))
                .andExpect(jsonPath("id",equalTo("CS0002")));
    }
    @Test
    @Order(2)
    void getDepartment() throws Exception {
        mockMvc.perform(get("/departments/CS005")
                    .header("X-USER-ID","nhnacademy"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE+";charset=UTF-8"))
                .andExpect(jsonPath("name",equalTo("CS5팀")));
    }
    @Test
    @Order(3)
    void updateDepartment() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        DepartmentDTO dto = new DepartmentDTO();
        dto.setName("CS1팀");
        mockMvc.perform(put("/departments/CS003")
                        .content(objectMapper.writeValueAsString(dto))
                        .header("X-USER-ID","nhnacademy")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    @Order(4)
    void deleteDepartment() throws Exception {
        mockMvc.perform(delete("/departments/CS0002")
                        .header("X-USER-ID","nhnacademy"))
                .andExpect(status().isOk());
    }
}