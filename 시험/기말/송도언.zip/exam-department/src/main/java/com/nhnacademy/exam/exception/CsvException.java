package com.nhnacademy.exam.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class CsvException extends RuntimeException{
    public CsvException(String message) {
        super(message);
    }
}
