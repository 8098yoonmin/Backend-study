package com.nhnacademy.exam.service;

import com.nhnacademy.exam.entity.Department;
import com.nhnacademy.exam.repository.DepartmentRepository;
import com.nhnacademy.exam.request.DepartmentDTO;
import com.nhnacademy.exam.response.DepartmentResponseDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
@Order(1)
public class DepartmentService {

    private final DepartmentRepository departmentRepository;

    @Transactional(readOnly = true)
    public DepartmentDTO getDepartment(String code){
        Department department = departmentRepository.findById(code).orElseThrow();
        return new DepartmentDTO(department.getDepartmentCode(),
                department.getDepartmentName());
    }

    public DepartmentResponseDTO createDepartment(DepartmentDTO dto){
        Department department = new Department(dto.getId(),dto.getName());
        departmentRepository.saveAndFlush(department);
        return new DepartmentResponseDTO(dto.getId());
    }

    public DepartmentDTO updateDepartment(String code,DepartmentDTO dto){
        Department department = departmentRepository.findById(code).orElseThrow();

        department.update(dto.getId(), dto.getName());

        departmentRepository.save(department);
        DepartmentDTO returnDTO = new DepartmentDTO();
        returnDTO.setName(dto.getName());
        return returnDTO;
    }

    public void deleteDepartment(String code){
        Department department = departmentRepository.findById(code).orElseThrow();

        departmentRepository.delete(department);
    }

    @Transactional(readOnly = true)
    public boolean existsDepartment(String code) {
        return departmentRepository.existsById(code);
    }
}
