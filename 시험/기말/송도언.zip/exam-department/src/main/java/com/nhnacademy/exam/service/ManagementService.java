package com.nhnacademy.exam.service;

import com.nhnacademy.exam.entity.Department;
import com.nhnacademy.exam.entity.Employee;
import com.nhnacademy.exam.entity.Management;
import com.nhnacademy.exam.repository.DepartmentRepository;
import com.nhnacademy.exam.repository.EmployeeRepository;
import com.nhnacademy.exam.repository.ManagementRepository;
import com.nhnacademy.exam.request.ManagementRequestDTO;
import com.nhnacademy.exam.response.ManagementDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
@Order(1)
public class ManagementService {

    private final ManagementRepository managementRepository;
    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;

    public void create(ManagementRequestDTO managementDTO){
        Employee employee = new Employee(managementDTO.getEmployeeId(), managementDTO.getEmployeeName());

        Department department = new Department(managementDTO.getDepartmentId(), managementDTO.getDepartmentName());

        Management management = new Management(
                new Management.Pk(managementDTO.getDepartmentId(), managementDTO.getEmployeeId()),
                employee,
                department);
        employeeRepository.save(employee);
        departmentRepository.save(department);
        managementRepository.saveAndFlush(management);
    }
    @Transactional(readOnly = true)
    public List<ManagementDTO> getDepartmentByEmployee(List<String> departmentIds) {
        List<Management> list = new ArrayList<>();

        departmentIds.forEach(departmentId ->
                list.addAll(managementRepository.findByDepartment_DepartmentCode(departmentId))
        );

        return list.stream()
                .map(m -> new ManagementDTO(employeeRepository.findById(m.getPk().getEmployeeId()).orElseThrow(),
                        departmentRepository.findById(m.getPk().getDepartmentCode()).orElseThrow()))
                .collect(Collectors.toList());
    }
}
