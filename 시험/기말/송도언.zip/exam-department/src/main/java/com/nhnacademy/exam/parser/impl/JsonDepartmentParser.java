package com.nhnacademy.exam.parser.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nhnacademy.exam.parser.DepartmentParser;
import com.nhnacademy.exam.request.JsonDTO;
import com.nhnacademy.exam.request.ManagementRequestDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Component
@Slf4j
@Order(2)
public class JsonDepartmentParser implements DepartmentParser {

    private final ObjectMapper objectMapper;
    @Override
    public String getFileType() {
        return "json";
    }

    @Override
    public List<ManagementRequestDTO> parsing(File file) throws IOException {

        List<JsonDTO> list = objectMapper.readValue(file, new TypeReference<>(){});

        return list.stream()
                .map(m -> new ManagementRequestDTO(m.get사번(),m.get이름(), m.get부서코드(), m.get부서()))
                .collect(Collectors.toList());
    }
}
