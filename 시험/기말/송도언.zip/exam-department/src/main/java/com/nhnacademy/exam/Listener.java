package com.nhnacademy.exam;

import com.nhnacademy.exam.parser.DepartmentParser;
import com.nhnacademy.exam.parser.DepartmentParserResolver;
import com.nhnacademy.exam.request.ManagementRequestDTO;
import com.nhnacademy.exam.service.ManagementService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;


@RequiredArgsConstructor
@Component
public class Listener implements ApplicationListener<ApplicationStartedEvent> {

    private final DepartmentParserResolver departmentParserResolver;

    private final ManagementService managementService;

    private static String FILE1="data/department-1.txt";
    private static String FILE2="data/department-2.txt";
    private static String FILE3="data/department.csv";
    private static String FILE4="data/department.json";

    private Resource resource1 = new PathMatchingResourcePatternResolver().getResource("classpath:" + FILE1);
    private Resource resource2 = new PathMatchingResourcePatternResolver().getResource("classpath:" + FILE2);
    private Resource resource3 = new PathMatchingResourcePatternResolver().getResource("classpath:" + FILE3);
    private Resource resource4 = new PathMatchingResourcePatternResolver().getResource("classpath:" + FILE4);
    List<List<ManagementRequestDTO>> listList = new ArrayList<>();
    @Override
    public void onApplicationEvent(ApplicationStartedEvent event) {


        DepartmentParser txt = departmentParserResolver.getDepartmentParser(FILE1);
        DepartmentParser txt2 = departmentParserResolver.getDepartmentParser(FILE2);
        DepartmentParser csv = departmentParserResolver.getDepartmentParser(FILE3);
        DepartmentParser json = departmentParserResolver.getDepartmentParser(FILE4);


        try {
            listList.add(txt.parsing(resource1.getFile()));
            listList.add(txt2.parsing(resource2.getFile()));
            listList.add(csv.parsing(resource3.getFile()));
            listList.add(json.parsing(resource4.getFile()));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        for(List<ManagementRequestDTO> list : listList){
            for(ManagementRequestDTO dto : list){
                managementService.create(dto);
            }
        }

    }
}