package com.nhnacademy.exam.advice;

import com.nhnacademy.exam.exception.*;
import com.nhnacademy.exam.response.ErrorDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;


@Slf4j
@RestControllerAdvice
public class CommonAdvice extends ResponseEntityExceptionHandler {

    @InitBinder
    void initBinder(WebDataBinder binder){
        binder.initDirectFieldAccess();
    }

    @ExceptionHandler(NotFoundDepartmentException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ResponseEntity<Object> notFoundException(NotFoundDepartmentException e) {
        ErrorDTO errorDTO = new ErrorDTO("department not found : " + e.getMessage()
                ,HttpStatus.NOT_FOUND.value()
                , LocalDateTime.now());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorDTO);
    }
    @ExceptionHandler(NotAllowedAcceptHeader.class)
    @ResponseStatus(value = HttpStatus.UNAUTHORIZED)
    public ResponseEntity<Object> notAllowed(NotAllowedAcceptHeader e) {
        ErrorDTO errorDTO = new ErrorDTO("Unauthorized"
                ,HttpStatus.UNAUTHORIZED.value()
                , LocalDateTime.now());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorDTO);
    }

    @ExceptionHandler(ExistDepartmentException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> notAllowed(ExistDepartmentException e) {
        ErrorDTO errorDTO = new ErrorDTO("부서 아이디 중복: " + e.getMessage()
                ,HttpStatus.BAD_REQUEST.value()
                , LocalDateTime.now());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorDTO);
    }

    @ExceptionHandler(CsvException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> csvError(CsvException e) {
        ErrorDTO errorDTO = new ErrorDTO("Could not find acceptable representation"
                ,HttpStatus.BAD_REQUEST.value()
                , LocalDateTime.now());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorDTO);
    }
    @ExceptionHandler(EmptyParameter.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> emptyParameter(EmptyParameter e) {
        ErrorDTO errorDTO = new ErrorDTO("Required request parameter 'departmentIds' for method parameter type String is not present"
                ,HttpStatus.BAD_REQUEST.value()
                , LocalDateTime.now());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorDTO);
    }
}
