package com.nhnacademy.exam.response;


import com.nhnacademy.exam.entity.Department;
import com.nhnacademy.exam.entity.Employee;
import lombok.*;

@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ManagementDTO {
    private Employee employee;
    private Department department;

}
