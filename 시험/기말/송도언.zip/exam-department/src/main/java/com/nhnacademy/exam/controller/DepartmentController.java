package com.nhnacademy.exam.controller;


import com.nhnacademy.exam.exception.CsvException;
import com.nhnacademy.exam.exception.ExistDepartmentException;
import com.nhnacademy.exam.exception.NotAllowedAcceptHeader;
import com.nhnacademy.exam.exception.NotFoundDepartmentException;
import com.nhnacademy.exam.request.DepartmentDTO;
import com.nhnacademy.exam.response.DepartmentResponseDTO;
import com.nhnacademy.exam.service.DepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

@RestController
@RequiredArgsConstructor
@RequestMapping("/departments")
public class DepartmentController {
    private final DepartmentService departmentService;

    @GetMapping("/{code}")
    public DepartmentDTO getDepartment(@RequestHeader(value = "X-User-ID") String user,
                                        @PathVariable String code){
        if (!Objects.equals(user, "nhnacademy")) {
            throw new NotAllowedAcceptHeader(user);
        }
        notFoundCheck(code);

        return departmentService.getDepartment(code);
    }

    @PostMapping
    public DepartmentResponseDTO createDepartment(@RequestHeader(value = "X-User-ID") String user,
                                                  @RequestHeader(value = "Content-Type") String accept,
                                               @RequestBody DepartmentDTO departmentDTO){

        checkHeader(user,accept);
        existCheck(departmentDTO.getId());
        return departmentService.createDepartment(departmentDTO);
    }

    @PutMapping("/{code}")
    public void updateDepartment(@RequestHeader(value = "X-User-ID") String user,
            @RequestHeader(value = "Content-Type") String accept,
            @PathVariable String code,
            @RequestBody DepartmentDTO departmentDTO){

        checkHeader(user,accept);

        departmentService.updateDepartment(code,departmentDTO);
    }

    @DeleteMapping("/{code}")
    public void deleteDepartment(@RequestHeader(value = "X-User-ID") String user,
            @PathVariable String code){
        if (!Objects.equals(user, "nhnacademy")) {
            throw new NotAllowedAcceptHeader(user);
        }
        departmentService.deleteDepartment(code);
    }

    private void notFoundCheck(String departmentId) {
        if (!departmentService.existsDepartment(departmentId)) {
            throw new NotFoundDepartmentException(departmentId);
        }
    }
    private void existCheck(String departmentId) {
        if (departmentService.existsDepartment(departmentId)) {
            throw new ExistDepartmentException(departmentId);
        }
    }


    private void checkHeader(String user, String accept){
        if (!Objects.equals(user, "nhnacademy")) {
            throw new NotAllowedAcceptHeader(accept);
        }
        if (!accept.contains("application/json") && !accept.contains("application/xml")) {
            throw new CsvException(accept);
        }
    }
}
