package com.nhnacademy.exam.controller;


import com.nhnacademy.exam.exception.CsvException;
import com.nhnacademy.exam.exception.EmptyParameter;
import com.nhnacademy.exam.exception.NotAllowedAcceptHeader;
import com.nhnacademy.exam.response.ManagementDTO;
import com.nhnacademy.exam.service.DepartmentService;
import com.nhnacademy.exam.service.ManagementService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequiredArgsConstructor
@RequestMapping("/department-members")
public class ManagementController {
    private final ManagementService managementService;
    private final DepartmentService departmentService;

    @GetMapping
    public List<ManagementDTO> getManagements(@RequestHeader(value = "X-USER-ID") String user,
                                              @RequestHeader(value = "Accept") String accept,
                                              @RequestParam(name = "departmentIds") List<String> departmentIds){
        checkHeader(user,accept);
        if(Objects.equals(departmentIds.size(),0)){
            throw new EmptyParameter(null);
        }
        for (String departmentId : departmentIds) {
            checkExistDepartment(departmentId);
        }
        return managementService.getDepartmentByEmployee(departmentIds);
    }


    private void checkExistDepartment(String departmentId) {
        if (!departmentService.existsDepartment(departmentId)) {
            throw new EmptyParameter(departmentId);
        }
    }

    private void checkHeader(String user, String accept){
        if (!Objects.equals(user, "nhnacademy")) {
            throw new NotAllowedAcceptHeader(accept);
        }
        if (!Objects.equals(accept, "application/json") && !Objects.equals(accept, "application/xml")) {
            throw new CsvException(accept);
        }
    }

}
