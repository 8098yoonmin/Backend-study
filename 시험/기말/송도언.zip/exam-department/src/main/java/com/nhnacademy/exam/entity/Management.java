package com.nhnacademy.exam.entity;


import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "management")
@Getter
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class Management {

    @EmbeddedId
    private Pk pk;
    @MapsId("employeeId")
    @JoinColumn(name="employee_id")
    @ManyToOne
    private Employee employee;

    @MapsId("departmentCode")
    @JoinColumn(name="department_code")
    @ManyToOne
    private Department department;

    @ToString
    @EqualsAndHashCode
    @NoArgsConstructor
    @AllArgsConstructor
    @Embeddable
    @Getter
    public static class Pk implements Serializable {
        @Column(name = "department_code")
        private String departmentCode;
        @Column(name="employee_id")
        private Long employeeId;
    }

}
