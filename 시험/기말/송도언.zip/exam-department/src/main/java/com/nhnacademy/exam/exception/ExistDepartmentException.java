package com.nhnacademy.exam.exception;


public class ExistDepartmentException extends RuntimeException{
    public ExistDepartmentException(String message) {
        super(message);
    }
}
