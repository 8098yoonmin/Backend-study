package com.nhnacademy.exam.parser.impl;

import com.nhnacademy.exam.parser.DepartmentParser;
import com.nhnacademy.exam.request.ManagementRequestDTO;
import com.nhnacademy.exam.util.CheckUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Slf4j
@Component
public class TextDepartmentParser implements DepartmentParser {

    @Override
    public String getFileType() {
        return "txt";
    }

    @Override
    public List<ManagementRequestDTO> parsing(File file) throws IOException {
        try(BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)))){
            String line;
            List<ManagementRequestDTO> list = new ArrayList<>();
            while((line = reader.readLine())!=null){
                String line2 = line.replace(" ","");
                String[] token = line2.split("\\|");
                if(CheckUtils.check(token[1]) &&Objects.nonNull(token[0])){
                        ManagementRequestDTO managementDTO = new ManagementRequestDTO(
                                Long.valueOf(token[1]),
                                token[2],
                                token[4],
                                token[3]
                        );
                        list.add(managementDTO);
                    }
            }
            return list;
        }
    }
}
