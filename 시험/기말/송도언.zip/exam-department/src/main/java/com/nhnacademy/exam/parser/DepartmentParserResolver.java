package com.nhnacademy.exam.parser;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nhnacademy.exam.parser.impl.CsvDepartmentParser;
import com.nhnacademy.exam.parser.impl.JsonDepartmentParser;
import com.nhnacademy.exam.parser.impl.TextDepartmentParser;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class DepartmentParserResolver {
    private final List<DepartmentParser> departmentParserList;

    public DepartmentParser getDepartmentParser(String fileName){
        String[] arg = fileName.split("\\.");
        for(DepartmentParser parser : departmentParserList){
            switch (arg[1]){
                case "txt":
                    return new TextDepartmentParser();
                case "csv":
                    return new CsvDepartmentParser();
                case "json":
                    return new JsonDepartmentParser(new ObjectMapper());
            }
        }
        return null;
    }
}
