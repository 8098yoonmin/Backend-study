package com.nhnacademy.exam.entity;


import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "employees")
@Getter
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class Employee {

    @Id
    @Column(name = "employee_id")
    private Long employeeId;

    @Column(name = "employee_name")
    private String employeeName;

    public void update(Long employeeId, String employeeName){
        if(employeeId != null){
            this.employeeId = employeeId;
        }
        if(employeeName != null){
            this.employeeName = employeeName;
        }
    }
}
