package com.nhnacademy.exam.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class JsonDTO {
    private Long 사번;
    private String 이름;
    private String 부서;
    private String 부서코드;
}
