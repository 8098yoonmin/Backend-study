package com.nhnacademy.exam.parser.impl;

import com.nhnacademy.exam.parser.DepartmentParser;
import com.nhnacademy.exam.request.ManagementRequestDTO;
import com.nhnacademy.exam.util.CheckUtils;
import lombok.extern.slf4j.Slf4j;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class CsvDepartmentParser implements DepartmentParser {

    @Override
    public String getFileType() {
        return "csv";
    }

    @Override
    public List<ManagementRequestDTO> parsing(File file) throws IOException {

        try(BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)))){
            String line;
            List<ManagementRequestDTO> list = new ArrayList<>();
            while((line = reader.readLine())!=null){
                String line2 = line.replace(" ","");
                String[] token = line2.split(",");
                if(!CheckUtils.check(token[0])) continue;
                ManagementRequestDTO managementDTO = new ManagementRequestDTO(
                        Long.valueOf(token[0]),
                        token[1],
                        token[3],
                        token[2]
                );
                list.add(managementDTO);
            }
            return list;
        }
    }
}
