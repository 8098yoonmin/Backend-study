package com.nhnacademy.exam.parser;

import com.nhnacademy.exam.request.ManagementRequestDTO;

import java.io.File;
import java.io.IOException;
import java.util.List;

public interface DepartmentParser {
     String getFileType();
     List<ManagementRequestDTO> parsing (File file) throws IOException;
     default boolean matchFileType(String fileName){
          return fileName.trim().toLowerCase().endsWith(getFileType().toLowerCase());
     }
}
