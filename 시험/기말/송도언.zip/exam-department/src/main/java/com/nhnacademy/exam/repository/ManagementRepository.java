package com.nhnacademy.exam.repository;

import com.nhnacademy.exam.entity.Management;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ManagementRepository extends JpaRepository<Management, Management.Pk> {

    List<Management> findByDepartment_DepartmentCode(String departmentCode);
}
