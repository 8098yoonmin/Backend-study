package com.nhnacademy.exam.util;

public class CheckUtils {

    private CheckUtils() {
        throw new IllegalStateException("Utility class");
    }

    public static boolean check(String arg){
        try {
            Long.parseLong(arg);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
