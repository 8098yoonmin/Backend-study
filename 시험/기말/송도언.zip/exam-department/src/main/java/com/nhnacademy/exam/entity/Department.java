package com.nhnacademy.exam.entity;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "departments")
@Getter
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class Department {

    @Id
    @Column(name = "department_code")
    private String departmentCode;

    @Column(name = "department_name")
    private String departmentName;

    public void update(String departmentCode, String departmentName){
        if(departmentCode != null){
            this.departmentCode = departmentCode;
        }
        if(departmentName != null){
            this.departmentName = departmentName;
        }
    }
}
