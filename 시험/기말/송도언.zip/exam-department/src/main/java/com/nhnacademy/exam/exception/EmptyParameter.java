package com.nhnacademy.exam.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class EmptyParameter extends RuntimeException{
    public EmptyParameter(String message) {
        super(message);
    }
}
