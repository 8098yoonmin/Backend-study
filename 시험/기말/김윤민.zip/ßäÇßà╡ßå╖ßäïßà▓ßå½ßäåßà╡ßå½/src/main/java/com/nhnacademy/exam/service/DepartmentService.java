package com.nhnacademy.exam.service;

import com.nhnacademy.exam.dto.DepartmentDTO;
import com.nhnacademy.exam.entity.Department;

import com.nhnacademy.exam.exception.NotFoundDepartmentException;
import com.nhnacademy.exam.repository.DepartmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

@Service
@RequiredArgsConstructor
@RequestMapping("/departments")
@Transactional
public class DepartmentService {

    private final DepartmentRepository departmentRepository;

    public DepartmentDTO findByDepartmentId(String departId){
        Department department = departmentRepository.findById(departId).orElseThrow(()-> new NotFoundDepartmentException());
        DepartmentDTO departmentDTO = new DepartmentDTO(department.getId(), department.getName());
        return departmentDTO;
    }

//    아이디 중복체크
    public DepartmentDTO register(DepartmentDTO departmentDTO){
        Department department = Department.builder()
                .id(departmentDTO.getId())
                .name(departmentDTO.getName())
                .build();
        departmentRepository.save(department);
        return departmentDTO;
    }

    public DepartmentDTO modifyDepartment(DepartmentDTO departmentDTO, String departId){
        Department data = departmentRepository.findById(departId).orElseThrow(()-> new NotFoundDepartmentException());
        Department department = new Department(data.getId(), departmentDTO.getName());
        departmentRepository.save(department);
        return departmentDTO;
    }

    public void deleteDepartment(String departId){
        Department data = departmentRepository.findById(departId).orElseThrow(()-> new NotFoundDepartmentException());
        departmentRepository.delete(data);
    }




}
