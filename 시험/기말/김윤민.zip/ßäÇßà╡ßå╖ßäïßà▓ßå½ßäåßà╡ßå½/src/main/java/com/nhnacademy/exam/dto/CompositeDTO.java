package com.nhnacademy.exam.dto;

import com.nhnacademy.exam.entity.Department;
import com.nhnacademy.exam.entity.Employee;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class CompositeDTO {
    private Department department;
    private Employee employee;
}
