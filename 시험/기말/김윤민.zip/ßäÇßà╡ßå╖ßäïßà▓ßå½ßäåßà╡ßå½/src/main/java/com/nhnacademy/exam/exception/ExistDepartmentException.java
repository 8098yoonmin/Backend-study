package com.nhnacademy.exam.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value= HttpStatus.BAD_REQUEST)
public class ExistDepartmentException extends RuntimeException{
    public ExistDepartmentException() {super("부서 아이디 중복");}
}
