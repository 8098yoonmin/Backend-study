package com.nhnacademy.exam.parser.impl;

import com.nhnacademy.exam.dto.CompositionRegisterDTO;
import com.nhnacademy.exam.parser.DepartmentParser;
import com.nhnacademy.exam.util.Checker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class CsvDepartmentParser implements DepartmentParser {

    @Override
    public String getFileType() {
        return "csv";
    }



        @Override
        public List<CompositionRegisterDTO> parsing(File file) throws IOException {
        List<CompositionRegisterDTO> compositons = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String line2 = line.replaceAll(" ","");
                String[] fields = line2.split(",");
                if(!Checker.check(fields[0])) {
                    continue;
                }
                    // CSV 파일의 각 라인을 파싱하여 Department 객체로 변환
                    CompositionRegisterDTO composition = parseComposition(fields);
                    compositons.add(composition);
                }
            }
         catch (IOException e) {
            log.error("Error occurred while parsing CSV file: {}", e.getMessage());
            throw e;
        }
        return compositons;
    }

        private CompositionRegisterDTO parseComposition(String[] fields){
            long id = Long.parseLong(fields[0]);
            String field1 = fields[1];
            String field2 = fields[2];
            String field3 = fields[3];
            return new CompositionRegisterDTO(id, field1, field3, field2);
        }


}
