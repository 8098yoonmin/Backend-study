package com.nhnacademy.exam.parser.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nhnacademy.exam.dto.CompositeDTO;
import com.nhnacademy.exam.dto.CompositionRegisterDTO;
import com.nhnacademy.exam.entity.Department;
import com.nhnacademy.exam.entity.Employee;
import com.nhnacademy.exam.parser.DepartmentParser;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Component
@Slf4j
public class JsonDepartmentParser implements DepartmentParser {

    private final ObjectMapper objectMapper;

    @Override
    public String getFileType() {
        return "json";
    }

    @Override
    public List<CompositionRegisterDTO> parsing(File file) throws IOException {
        List<CompositionRegisterDTO> compositions = new ArrayList<>();
        JsonNode rootNode = objectMapper.readTree(file);
        if (rootNode.isArray()) {
            for (JsonNode node : rootNode) {
                Long employeeNumber = node.get("사번").asLong();
                String employeeName = node.get("이름").asText();
                String departmentName = node.get("부서").asText();
                String departmentCode = node.get("부서코드").asText();

                CompositionRegisterDTO composition = new CompositionRegisterDTO(employeeNumber, employeeName,departmentName,departmentCode );
                compositions.add(composition);
            }
        }
       return compositions;
    }
}
