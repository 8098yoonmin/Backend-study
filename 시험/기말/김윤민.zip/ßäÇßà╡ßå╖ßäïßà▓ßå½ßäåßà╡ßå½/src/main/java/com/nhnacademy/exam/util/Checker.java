package com.nhnacademy.exam.util;

public class Checker {

    public static boolean check(String arg){
        return isNumeric(arg);
    }

    private static boolean isNumeric(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }

        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }

        return true;
    }
}
