package com.nhnacademy.exam.dto;


import lombok.*;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class CompositionRegisterDTO {
    private Long employeeId;
    private String employeName;
    private String departmentName;
    private String departmentId;

}
