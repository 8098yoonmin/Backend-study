//package com.nhnacademy.exam.listenser;
//
//import com.nhnacademy.exam.dto.CompositionRegisterDTO;
//import com.nhnacademy.exam.parser.DepartmentParser;
//import com.nhnacademy.exam.parser.DepartmentParserResolver;
//import com.nhnacademy.exam.service.CompositeService;
//import lombok.RequiredArgsConstructor;
//import org.springframework.boot.context.event.ApplicationStartedEvent;
//import org.springframework.context.ApplicationListener;
//import org.springframework.core.io.Resource;
//import org.springframework.core.io.ResourceLoader;
//import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
//import org.springframework.stereotype.Component;
//
//import java.io.File;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//
//@Component
//@RequiredArgsConstructor
//public class SaveData implements ApplicationListener<ApplicationStartedEvent> {
////    private final ResourceLoader resourceLoader;
//    private final CompositeService compositeService;
//    private final DepartmentParserResolver departmentParserResolver;
//    private String file = "data/department.json";
//    private Resource resource = new PathMatchingResourcePatternResolver().getResource("classpath:"+ file);
//    List<CompositionRegisterDTO> list = new ArrayList<>();
//
//    @Override
//    public void onApplicationEvent(ApplicationStartedEvent event) {
//        DepartmentParser jsonFile = departmentParserResolver.getDepartmentParser(file);
//        try {
//            list.addAll(jsonFile.parsing(resource.getFile()));
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//        for(CompositionRegisterDTO dto: list){
//            compositeService.saveFile(dto);
//
//        }
//
////        try{
////            Resource resource = resourceLoader.getResource("classpath:data/department.json");
////            File file = resource.getFile();
////            DepartmentParser jsonParser = departmentParserResolver.getDepartmentParser(file.getName());
////            if(jsonParser != null){
////                List<CompositionRegisterDTO> data = jsonParser.parsing(file);
////                for(CompositionRegisterDTO dto : data){
////                    compositeService.saveFile(dto);
////                }
////            }
////        } catch (IOException e) {
////            throw new RuntimeException(e);
////        }
//
//
//    }
//}
