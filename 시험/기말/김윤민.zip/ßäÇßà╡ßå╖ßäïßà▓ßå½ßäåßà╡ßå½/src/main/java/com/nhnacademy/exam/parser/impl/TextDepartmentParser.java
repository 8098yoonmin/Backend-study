package com.nhnacademy.exam.parser.impl;

import com.nhnacademy.exam.dto.CompositionRegisterDTO;
import com.nhnacademy.exam.parser.DepartmentParser;
import com.nhnacademy.exam.util.Checker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Slf4j
@Component
public class TextDepartmentParser implements DepartmentParser {

    @Override
    public String getFileType() {
        return "txt";
    }

    @Override
    public List<CompositionRegisterDTO> parsing(File file) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
        String line;
        List<CompositionRegisterDTO> list = new ArrayList<>();
        while((line = reader.readLine())!=null){
            String line2 = line.replaceAll(" ","");
            String[] fields = line2.split("\\|");
            if(Checker.check(fields[1])){
                if(fields[0]!=null){
                    CompositionRegisterDTO managementDTO = new CompositionRegisterDTO(
                            Long.valueOf(fields[1]),
                            fields[2],
                            fields[4],
                            fields[3]
                    );
                    list.add(managementDTO);
                }
            }
        }
        return list;
    }



}