package com.nhnacademy.exam.entity;

import lombok.*;

import javax.persistence.*;

@Entity
@Getter
@Builder
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "department")
public class Department {

    @Id
    @Column(name = "department_id")
    private String id;

    @Column(name = "department_name")
    private String name;

}