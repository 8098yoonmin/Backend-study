package com.nhnacademy.exam.controller;

import com.nhnacademy.exam.dto.DepartmentDTO;
import com.nhnacademy.exam.entity.Department;
import com.nhnacademy.exam.service.DepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/departments")
public class DepartmentController {
    private final DepartmentService departmentService;

    @PostMapping
    public ResponseEntity<DepartmentDTO> registerDepartment(@RequestBody DepartmentDTO departmentDTO){
        DepartmentDTO department = departmentService.register(departmentDTO);
        return ResponseEntity.ok(department);
    }

    @GetMapping("/{id}")
    public ResponseEntity<DepartmentDTO> getDepartment(@PathVariable("id")String departCode){
        DepartmentDTO department = departmentService.findByDepartmentId(departCode);
        return ResponseEntity.ok(department);
    }

    @PutMapping("/{id}")
    public ResponseEntity<DepartmentDTO> modifyDepartment(@PathVariable("id")String departId, @RequestBody DepartmentDTO departmentDTO){
        DepartmentDTO department = departmentService.modifyDepartment(departmentDTO, departId);
        return ResponseEntity.ok(department);
    }

    @DeleteMapping("/{id}")
    public void deleteDepartment(@PathVariable("id")String departCode){
        departmentService.deleteDepartment(departCode);
    }

}
