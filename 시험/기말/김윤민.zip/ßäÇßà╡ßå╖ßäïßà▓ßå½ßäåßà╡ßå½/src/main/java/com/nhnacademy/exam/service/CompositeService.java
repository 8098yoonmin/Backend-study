package com.nhnacademy.exam.service;

import com.nhnacademy.exam.dto.CompositionRegisterDTO;
import com.nhnacademy.exam.entity.Composition;
import com.nhnacademy.exam.entity.Department;
import com.nhnacademy.exam.entity.Employee;
import com.nhnacademy.exam.repository.CompositeRepository;
//import com.nhnacademy.exam.repository.CompositionRepositoryCustom;
import com.nhnacademy.exam.repository.DepartmentRepository;
import com.nhnacademy.exam.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@RequiredArgsConstructor
@Service
@Transactional
public class CompositeService {

    private final CompositeRepository compositeRepository;
    private final DepartmentRepository departmentRepository;
    private final EmployeeRepository employeeRepository;

    public Composition saveFile(CompositionRegisterDTO compositionRegisterDTO){
        Department department = new Department(
                compositionRegisterDTO.getDepartmentId(),
                compositionRegisterDTO.getDepartmentName()
        );
        Employee employee = new Employee(
                compositionRegisterDTO.getEmployeeId(),
                compositionRegisterDTO.getEmployeName()
        );
        Composition composition = new Composition(
                new Composition.Pk( employee.getEmployeeId(),department.getId()),
                employee,
                department
        );

        departmentRepository.save(department);
        employeeRepository.save(employee);
        compositeRepository.save(composition);
        return composition;
    }




}
