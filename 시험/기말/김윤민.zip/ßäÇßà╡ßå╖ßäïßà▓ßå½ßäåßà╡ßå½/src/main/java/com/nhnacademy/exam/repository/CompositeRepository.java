package com.nhnacademy.exam.repository;

import com.nhnacademy.exam.entity.Composition;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompositeRepository extends JpaRepository<Composition, Composition.Pk> {
}
