package com.nhnacademy.edu.springframework.repository;

import java.util.List;

public interface RatetableStorage {

    void csvLoad(DataParser parser);

    List<WaterBill> findPayout(long usage);

}
