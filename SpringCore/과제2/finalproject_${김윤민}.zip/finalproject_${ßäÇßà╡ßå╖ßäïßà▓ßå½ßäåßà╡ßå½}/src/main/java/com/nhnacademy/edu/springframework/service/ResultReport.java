package com.nhnacademy.edu.springframework.service;

import java.util.List;

public interface ResultReport {

   void report(List list);
}
