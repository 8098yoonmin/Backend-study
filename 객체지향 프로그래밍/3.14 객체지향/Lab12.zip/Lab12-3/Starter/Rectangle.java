public class Rectangle {
    protected int witdh;
    protected int height;

    //
    // To-do: Write getters here.
    //
    
    //
    // To-do: Write setters here.
    //

    //
    // To-do: Write getArea method here
    //
}