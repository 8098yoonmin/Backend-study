public class Square extends Rectangle {
    //
    // To-do: Write setWidth override method here
    //
    

    //
    // To-do: Write setHeight override method here
    //
}
