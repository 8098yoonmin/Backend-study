public interface IPrint {
    void printAccount(IAccount account);
}
