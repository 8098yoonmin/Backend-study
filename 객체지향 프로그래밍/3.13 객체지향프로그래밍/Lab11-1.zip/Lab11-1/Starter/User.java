class User { //implements Comparable<User> {
    private final int userNo;
    private final String userName;
    private final int userAge;

    public int getUserAge() {
        return userAge;
    }

    public User(int userNo, String userName, int userAge) {
        this.userNo = userNo;
        this.userName = userName;
        this.userAge = userAge;
    }

    //
    // To-do: override compareTo method here
    //

    //
    // To-do: override toString method here
    //
}