public interface Drink {
    String getName();
    void make();
    int getPrice();
}
