package com.nhnacademy.firstdbcp.controller;

public class airinfo {
}
